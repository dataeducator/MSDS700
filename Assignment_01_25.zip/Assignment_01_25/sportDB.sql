DROP SCHEMA IF EXISTS sport ;
CREATE SCHEMA sport;
USE sport;

-- city
-- sz is the size:1 small, 2 medium, 3 large
CREATE TABLE IF NOT EXISTS city (
  id int NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  sz INT NULL DEFAULT NULL,
  PRIMARY KEY (id));

-- teams table
CREATE TABLE IF NOT EXISTS teams (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NULL DEFAULT NULL,
  id_city int NULL DEFAULT NULL,
  PRIMARY KEY (id),
  foreign key(id_city) references city(id)
  );

-- players table
CREATE TABLE IF NOT EXISTS players (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NULL DEFAULT NULL,
  id_team INT NULL DEFAULT NULL,
  PRIMARY KEY (id),
  foreign key(id_team) references teams(id)
  );

----
insert into city values(1,'LA', 3);
insert into city values(2,'Chicago', 2);
insert into city values(3,'Jokeville', 1); 
insert into city values(4,'Miami', 2); 
insert into city values(5,'Nashville', 2); 
--
insert into teams values (1,'Dreamteam', 1);
insert into teams values (2,'Starteam', 2);
insert into teams values (3,'Loosers', 3);
--
insert into players values (1,'Kareem Abduljabbar', 1);
insert into players values (2,'Charles Barkley', 1);
insert into players values (3,'Hakeem Olajuwon', 1);
insert into players values (4,'John Stockton', 2);
insert into players values (5,'Shaquille ONeal', 2);
insert into players values (6,'Lebron James', 2);
insert into players (id, name) values (7,'Poor Guy');
--- 
